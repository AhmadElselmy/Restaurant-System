package javaapplication10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name ="reservationlist" )
@XmlAccessorType(XmlAccessType.FIELD)
public class ReservationList {
  @XmlElement(name="managers")
    private Managers managers = null;
     @XmlElement(name="cookers")
    private Cookers cookers = null;
      @XmlElement(name="waiters")
    private Waiters waiters = null;

    public Managers getManagers() {
        return managers;
    }

    public void setManagers(Managers managers) {
        this.managers = managers;
    }

    public Cookers getCookers() {
        return cookers;
    }

    public void setCookers(Cookers cookers) {
        this.cookers = cookers;
    }

    public Waiters getWaiters() {
        return waiters;
    }

    public void setWaiters(Waiters waiters) {
        this.waiters = waiters;
    }

}
