package javaapplication10;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AlertBoxes {
Stage Alert = new Stage();

public void alertboxes(){
Alert.setTitle("Error!");
Label Warning = new Label("Thereis no such a table sorry!");
Button tryagain = new Button("Try Another Table!");
Button Logout = new Button("Logout");
Button Exit = new Button("Exit");

    HBox hbox = new HBox();
    hbox.getChildren().addAll(tryagain,Logout,Exit);
    hbox.setPadding(new Insets(10,10,10,10));
    hbox.setSpacing(50);

    VBox vbox = new VBox();
    vbox.getChildren().addAll(Warning,hbox);
    Customer customer = new Customer();

     Logout.setOnAction(e->{
        Alert.close();
        customer.customerWindow.close();
        
    });
    Exit.setOnAction(e1->{
        System.exit(0);
    });
    
    tryagain.setOnAction(e2->{
       Alert.close(); 
    });
    Scene scene = new Scene(vbox);
    Alert.setScene(scene);
    Alert.showAndWait();
    
}

}
