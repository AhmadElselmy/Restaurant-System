package javaapplication10;

import java.io.File;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "cooker")
@XmlAccessorType(XmlAccessType.FIELD)

public class Cooker extends Person {
        @XmlElement(name= "Order")
    private List<String> order;
    @XmlElement(name= "Quantity")
    private List<Integer> quantity;
    @XmlElement(name= "NumberOfTheTable")
    private int numberofthetable;

     public Cooker(){
    }
    
    public Cooker(List<String> ordername,List<Integer> quantity,int tableNumber){
        this.order=ordername;
        this.quantity=quantity;
        this.numberofthetable=tableNumber;
    }
   
    public List<String> getOrder() {
        return order;
    }

    public void setOrder(List<String> order) {
        this.order = order;
    }

    public List<Integer> getQuantity() {
        return quantity;
    }

    public void setQuantity(List<Integer> quantity) {
        this.quantity = quantity;
    }

    public int getNumberofthetable() {
        return numberofthetable;
    }

    public void setNumberofthetable(int numberofthetable) {
        this.numberofthetable = numberofthetable;
    }

    public void CookerDashboard(String name) throws JAXBException{
    Stage cookermenu = new Stage();
    cookermenu.setTitle("Cooker's Menu");
    Label welcomingLabel = new Label("Welcome "+ name+"!");
    TableView<Cooker> cookertable;
    Button Logout = new Button("Logout");
    Button Exit = new Button("Exit");
    
  TableColumn<Cooker, String> ordercolumn = new TableColumn<>("Order");
  TableColumn<Cooker, String> quantitycolumn = new TableColumn<>("Quantity");
  TableColumn<Cooker, String> numbercolumn = new TableColumn<>("Number of the table");
  
  ordercolumn.setMinWidth(150);
  quantitycolumn.setMinWidth(150);
  numbercolumn.setMinWidth(150);
  
  ordercolumn.setCellValueFactory(new PropertyValueFactory<>("order"));
  quantitycolumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
  numbercolumn.setCellValueFactory(new PropertyValueFactory<>("numberofthetable"));
  
    cookertable= new TableView<>();
    cookertable.setItems(CookerList());
    cookertable.getColumns().addAll(ordercolumn,quantitycolumn,numbercolumn);
  
    HBox hbox = new HBox();
    hbox.getChildren().addAll(Logout,Exit);
    hbox.setPadding(new Insets(10,10,10,10));
    hbox.setSpacing(50);
    
    
    VBox vBox = new VBox();
    vBox.setPadding(new Insets(10,10,10,10));
    vBox.setSpacing(20);
    vBox.getChildren().addAll(welcomingLabel,cookertable,hbox);
   
    
    Logout.setOnAction(e->{
        cookermenu.close();

    });
    Exit.setOnAction(e1->{
        System.exit(0);
    });
    Scene scene = new Scene(vBox);
    cookermenu.setScene(scene);
    cookermenu.showAndWait();
    
    
    }
    public ObservableList<Cooker> CookerList() throws JAXBException{
        ObservableList<Cooker> lists = FXCollections.observableArrayList();
        Cooker tc[] = new Cooker[100];
        int i=0; 
        JAXBContext jaxbContext = JAXBContext.newInstance(ReservationList.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        ReservationList reservationlist = (ReservationList)unmarshaller.unmarshal(new File("save.xml"));
    for(Cooker cooker:reservationlist.getCookers().getCookersXML()){ 
       tc[i]=new Cooker();
        tc[i].setOrder(cooker.getOrder());
        tc[i].setQuantity(cooker.getQuantity());
        tc[i].setNumberofthetable(cooker.getNumberofthetable());
       lists.add(new Cooker(tc[i].getOrder(),tc[i].getQuantity(),tc[i].getNumberofthetable()));
        i++;
    }
    return lists;}
    
    
}
