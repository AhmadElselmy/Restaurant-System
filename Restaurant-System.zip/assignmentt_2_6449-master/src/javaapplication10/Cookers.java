package javaapplication10;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "cookers")
@XmlAccessorType(XmlAccessType.FIELD)

public class Cookers {
    @XmlElement(name = "cooker")
    private List<Cooker> cookers;

    public List<Cooker> getCookersXML() {
        return cookers;
    }

    public void setCookersXML(List<Cooker> cookers) {
        this.cookers = cookers;
    }
    
}
