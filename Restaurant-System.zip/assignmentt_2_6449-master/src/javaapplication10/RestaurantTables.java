package javaapplication10;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
@XmlRootElement(name="restaurant")
@XmlAccessorType(XmlAccessType.FIELD)
public class RestaurantTables {
    @XmlElement(name="tables")
    private Tables tables = null;
    public Tables getTables() {
        return tables;
    }
    public void setTables(Tables tables) {
        this.tables = tables;
    }

    
}

