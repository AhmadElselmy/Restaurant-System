package javaapplication10;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import org.xml.sax.SAXException;

public class Customer extends Person {
int m=0;
double totalprice;
TableView<Dish> menutable; 
Reservations reservations = new Reservations();
Stage customerWindow = new Stage();
Stage menuwindow = new Stage(); 
Table table1 = new Table();
        
    
  public void displayingmenu(String Name,Table table) throws JAXBException{
int n =0;
  menuwindow.setTitle("Menu");
  Dish selected2[]=new Dish[100];
  ArrayList<String> selectedfood = new ArrayList<>();
  ArrayList<String> selectedquantity = new ArrayList<>();
  Button Add = new Button("Add to the cart");
  TextField quantity = new TextField();
  Label totalPrice = new Label("Total Price after taxes:-");  
  Label taxes = new Label("Taxes:-");
  Label taxesresult = new Label("0");
  Label priceresult = new Label("0");
  Label totalpriceresult = new Label("0");
  Label price = new Label("Price Before Taxes:-");
  quantity.setPromptText("Quantity");
  Button Reserve = new Button("Ready To Resereve!");
  
  TableColumn<Dish, String> namecolumn = new TableColumn<>("Name");
  TableColumn<Dish, Double> pricecolumn = new TableColumn<>("Price");
  TableColumn<Dish, String> typecolumn = new TableColumn<>("Type");
  
  namecolumn.setMinWidth(200);
  pricecolumn.setMinWidth(100);
  typecolumn.setMinWidth(200);
  
  namecolumn.setCellValueFactory(new PropertyValueFactory<>("name"));
  pricecolumn.setCellValueFactory(new PropertyValueFactory<>("price"));
  typecolumn.setCellValueFactory(new PropertyValueFactory<>("type"));
  Reserve.setOnAction(e->{
      Reservations userinfo = new Reservations();
    try {
        userinfo.SaveReservation(Name,selectedfood,selectedquantity,table,m,totalprice);
    } catch (JAXBException | FileNotFoundException ex) {
        Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
    }
      Stage Exitmenu = new Stage();
      Exitmenu.setWidth(300);
      Exitmenu.setTitle("Have an amazing day!");
      Label bye = new Label("Reservation completed successfully!");
      Button Logout = new Button("Logout");
      Logout.setOnAction(e2->{
          Exitmenu.close();
          menuwindow.close();
          customerWindow.close();

          
      });
      Button Exit = new Button("Exit");
      Exit.setOnAction(e1->System.exit(0));
      HBox hbox = new HBox();
      hbox.setPadding(new Insets(10,10,10,10));
      hbox.setSpacing(10);
      hbox.getChildren().addAll(Logout,Exit);
      VBox vbox= new VBox();
      vbox.setPadding(new Insets(10,10,10,10));
      vbox.getChildren().addAll(bye,hbox);
      Scene scene = new Scene(vbox);
      Exitmenu.setScene(scene);
      Exitmenu.showAndWait();
    
  });
  
  menutable= new TableView<>();
  menutable.setItems(getDishes());
  menutable.getColumns().addAll(namecolumn,pricecolumn,typecolumn);
 
  Add.setOnAction(e->{
   Dish selected = menutable.getSelectionModel().getSelectedItem(); 
   selected2[m]=menutable.getSelectionModel().getSelectedItem();
   selected2[m].setQuantity(quantity.getText());  
   if(selected.getType().equals("appetizer")){
   taxesresult.setText(Double.toString(((selected.getPrice()*Double.parseDouble(quantity.getText()))*0.1)+Double.parseDouble(taxesresult.getText())));
   priceresult.setText(Double.toString((selected.getPrice()*Double.parseDouble(quantity.getText()))+Double.parseDouble(priceresult.getText())));
  selectedfood.add(selected2[m].getName());
  selectedquantity.add(selected2[m].getQuantity());
   m++;
   }
   else if(selected.getType().equals("main_course")){
   taxesresult.setText(Double.toString(((selected.getPrice()*Double.parseDouble(quantity.getText()))*0.15)+Double.parseDouble(taxesresult.getText())));
   priceresult.setText(Double.toString(selected.getPrice()*Double.parseDouble(quantity.getText())+Double.parseDouble(priceresult.getText())));
   selectedfood.add(selected2[m].getName());
  selectedquantity.add(selected2[m].getQuantity());
   m++;}
   else if(selected.getType().equals("desert")){
   taxesresult.setText(Double.toString(((selected.getPrice()*Double.parseDouble(quantity.getText()))*0.2)+Double.parseDouble(taxesresult.getText())));
   priceresult.setText(Double.toString(selected.getPrice()*Double.parseDouble(quantity.getText())+Double.parseDouble(priceresult.getText())));
   selectedfood.add(selected2[m].getName());
  selectedquantity.add(selected2[m].getQuantity());
   m++;}
  totalpriceresult.setText(Double.toString((Double.parseDouble(taxesresult.getText())+Double.parseDouble(priceresult.getText()))));
  totalprice=Double.parseDouble(totalpriceresult.getText());
  });
  
      
    HBox hBox = new HBox();
    hBox.setPadding(new Insets(10,10,10,10));
    hBox.setSpacing(10);
    hBox.getChildren().addAll(quantity,Add);
    
    HBox hBox2 = new HBox();
    hBox2.setPadding(new Insets(10,10,10,10));
    hBox2.setSpacing(10);
    hBox2.getChildren().addAll(price,priceresult,taxes,taxesresult,totalPrice,totalpriceresult);
       
    
    VBox vBox = new VBox();
    vBox.getChildren().addAll(menutable,hBox,hBox2,Reserve);
    
    Scene scene = new Scene(vBox);
    menuwindow.setScene(scene);
    menuwindow.showAndWait();
    }
    
    
    public void displayingmenu2() throws JAXBException{
    menuwindow.setTitle("Menu");
  
    Button Done = new Button("Done");
    
   Done.setOnAction(e->{
       menuwindow.close();
   });
    
  TableColumn<Dish, String> namecolumn = new TableColumn<>("Name");
  TableColumn<Dish, Double> pricecolumn = new TableColumn<>("Price");
  TableColumn<Dish, String> typecolumn = new TableColumn<>("Type");
  
  namecolumn.setMinWidth(200);
  pricecolumn.setMinWidth(100);
  typecolumn.setMinWidth(200);
  
  namecolumn.setCellValueFactory(new PropertyValueFactory<>("name"));
  pricecolumn.setCellValueFactory(new PropertyValueFactory<>("price"));
  typecolumn.setCellValueFactory(new PropertyValueFactory<>("type"));
  
  menutable= new TableView<>();
  menutable.setItems(getDishes());
  menutable.getColumns().addAll(namecolumn,pricecolumn,typecolumn);

    VBox vBox = new VBox();
    vBox.getChildren().addAll(menutable,Done);
   
   
    
    Scene scene = new Scene(vBox);
    menuwindow.setScene(scene);
    menuwindow.showAndWait();
    }
    
    
    
    public ObservableList<Dish> getDishes() throws JAXBException{
    ObservableList<Dish> dishes = FXCollections.observableArrayList();
    Dish td[] = new Dish[100];
    int i=0; 
        JAXBContext jaxbContext = JAXBContext.newInstance(RestaurantDishes.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        RestaurantDishes restaurant = (RestaurantDishes)unmarshaller.unmarshal(new File("Restaurant.xml"));
    for(Dish dish:restaurant.getDishes().getDishes()){ 
       td[i]=new Dish();
        td[i].setName(dish.getName());
        td[i].setPrice(dish.getPrice());
        td[i].setType(dish.getType());
    dishes.add(new Dish(td[i].getName(),td[i].getPrice(),td[i].getType()));
        i++;
      }
    return dishes;}
    
    public boolean checkingvalidation(String numberofseats,String smoke) throws JAXBException, TransformerException, ParserConfigurationException, SAXException, IOException, XPathExpressionException{
           Table tablee = new Table();
    Tables tablees = new Tables();
    List<Table> tableelist = new ArrayList<>();
   
        int flag=0, i=0,t,p=0;
    boolean x = smoke.equals("Yes");
    boolean y=false;
    File file = new File("TablesReserved.xml");
    Table t1[] = new Table[100];
    Table t2[] = new Table[100];
    JAXBContext jaxbContext = JAXBContext.newInstance(RestaurantTables.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        RestaurantTables restaurant = (RestaurantTables)unmarshaller.unmarshal(new File("Restaurant.xml"));
        for(Table table:restaurant.getTables().getTables()){
        t1[i]=new Table();
        t1[i].setNumber(table.getNumber());
        t1[i].setNumber_of_seats(table.getNumber_of_seats());
        t1[i].setSmoking(table.getSmoking());
        i++;
      }
        BufferedReader br = new BufferedReader(new FileReader("TablesReserved.xml"));

    for(t=0;t<i;t++){
    if((numberofseats.equals(t1[t].getNumber_of_seats())==true)&&(Boolean.compare(x, t1[t].getSmoking())==0)){
        
        
        if(br.readLine()==null){ 
        tablee.setNumber(1);
        tablee.setNumber_of_seats(numberofseats);
        tablee.setSmoking(x);
        tableelist.add(tablee);
        tablees.setTables(new ArrayList(tableelist));
        restaurant.setTables(tablees);
             try{
        Marshaller marshall = jaxbContext.createMarshaller();
        marshall.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,Boolean.TRUE);
        OutputStream output = new FileOutputStream("TablesReserved.xml");
        marshall.marshal(restaurant,output);
    }
    catch(JAXBException e1){
        System.out.println("error jaxb 1");
    }
    catch(FileNotFoundException ex){
        System.out.println("error cannot find file;");
    }   
         }
         else if(br.readLine()!=null){
             flag = 1;
            Unmarshaller unmarshaller2 = jaxbContext.createUnmarshaller();
             RestaurantTables restaurant2 =(RestaurantTables)unmarshaller2.unmarshal(file);
             for(Table table:restaurant2.getTables().getTables()){
        t2[p]=new Table();
        t2[p].setNumber(table.getNumber());
        t2[p].setNumber_of_seats(table.getNumber_of_seats());
        t2[p].setSmoking(table.getSmoking());
        p++;
      }}}}
    if(flag==0){
    for(t=0;t<i;t++){
    if((numberofseats.equals(t1[t].getNumber_of_seats())==true)&&(Boolean.compare(x, t1[t].getSmoking())==0)){
        y=true;
    table1.setNumber(t1[t].getNumber());
    }
    }
    }
    else if(flag==1){
    for(t=0;t<i;t++){
    for(int g=0;g<p;g++){           
    if((numberofseats.equals(t1[t].getNumber_of_seats())==true)&&(Boolean.compare(x, t1[t].getSmoking())==0)){
        if((t1[t].getNumber_of_seats()!=t2[g].getNumber_of_seats())&&(t1[t].getSmoking()!=t2[g].getSmoking())){
        y=true;
    table1.setNumber(t1[t].getNumber());
    }
    }
        }
    }
    }
      return y;}
    public  void displayCustomer(String Name) {
    GridPane grid = new GridPane();
    grid.setPadding(new Insets(10,10,10,10));
    grid.setVgap(8);
    grid.setHgap(15);
    
   

    ComboBox<String> combobox=new ComboBox<>();
    combobox.getItems().addAll(
            "Reserve a Table",
            "Have a Look on our menu"
    );
    combobox.setPromptText("What do you wish to do next?");
    
    Label WelcomingLabel = new Label("Welcome to the restaurant "+Name+"!" );
   
    Button Next = new Button("Next");
    
    Label numberofseatslabel = new Label("Number of seats required?");
    
    TextField numberofseatstext = new TextField();
    
    Label smokingLabel=new Label("Do you want in in the smoking area?");
    ListView<String> listview;
    listview = new ListView<>();
    RadioButton radiobutton1= new RadioButton("Yes");
    RadioButton radiobutton2= new RadioButton("No"); 
    Button Next1 = new Button("Next");
    ToggleGroup radioGroup = new ToggleGroup();
    radiobutton1.setToggleGroup(radioGroup);
    radiobutton2.setToggleGroup(radioGroup);

    
    Next.setOnAction(e->{
        if(combobox.getValue().startsWith("Reserve")==true){
    GridPane.setConstraints(numberofseatslabel, 0, 5);
    GridPane.setConstraints(numberofseatstext, 2, 5);
    GridPane.setConstraints(smokingLabel, 0, 7);
    GridPane.setConstraints(radiobutton1, 2, 7);
    GridPane.setConstraints(radiobutton2, 3, 7);
    GridPane.setConstraints(Next1, 1, 8);
   grid.getChildren().addAll(Next1,radiobutton1,radiobutton2,numberofseatslabel,numberofseatstext,smokingLabel);}
        else{
            try {
                displayingmenu2();
            } catch (JAXBException ex) {
                Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
            }
        } 
    });
    
    Next1.setOnAction(e->{
        try {
            RadioButton selectedradiobutton= (RadioButton)radioGroup.getSelectedToggle();
            try {
                if(checkingvalidation(numberofseatstext.getText(),selectedradiobutton.getText())==true){
                    
                    displayingmenu(Name,table1);}
                              else{
                   AlertBoxes alert = new AlertBoxes();
                   alert.alertboxes();
                }
  
            } catch (TransformerException | ParserConfigurationException | SAXException | IOException | XPathExpressionException ex) {
                Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (JAXBException ex) {
            Logger.getLogger(Customer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    });
   GridPane.setConstraints(Next, 1, 2); 
   GridPane.setConstraints(WelcomingLabel, 1, 0);
   GridPane.setConstraints(combobox, 1, 1);
   grid.getChildren().addAll(WelcomingLabel,combobox,Next);
   
   Scene scene = new Scene(grid,700,500);
   customerWindow.setScene(scene);
   customerWindow.showAndWait();

    }
   
}
