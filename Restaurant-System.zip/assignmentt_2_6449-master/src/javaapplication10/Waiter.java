package javaapplication10;

import java.io.File;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "waiter")
@XmlAccessorType(XmlAccessType.FIELD)

public class Waiter extends Person {
    @XmlElement(name= "NameOfTheCustomer")
    private String nameofthecustomer;
    @XmlElement(name= "NumberOfTheTable")
    private int numberofthetable;
    
    public Waiter(){
    }
    
    public Waiter(String clientname,int tableNumber){
        this.nameofthecustomer=clientname;
        this.numberofthetable=tableNumber;
    }
    
    public String getNameofthecustomer() {
        return nameofthecustomer;
    }

    public void setNameofthecustomer(String nameofthecustomer) {
        this.nameofthecustomer = nameofthecustomer;
    }

    public void Waiterdashboard(String name) throws JAXBException{
    Stage waitermenu = new Stage();
    waitermenu.setTitle("Waiter's Menu");
    Label welcomingLabel = new Label("Welcome "+ name);
    TableView<Waiter> waitertable;
    Button Logout = new Button("Logout");
    Button Exit = new Button("Exit");
    
  TableColumn<Waiter, String> namecolumn = new TableColumn<>("Name");
  TableColumn<Waiter, String> Numbercolumn = new TableColumn<>("Number of the table");
  
  namecolumn.setMinWidth(200);
  Numbercolumn.setMinWidth(200);
  
  namecolumn.setCellValueFactory(new PropertyValueFactory<>("nameofthecustomer"));
  Numbercolumn.setCellValueFactory(new PropertyValueFactory<>("numberofthetable"));
  
    waitertable= new TableView<>();
    waitertable.setItems(WaiterList());
    waitertable.getColumns().addAll(namecolumn,Numbercolumn);
  
    HBox hbox = new HBox();
    hbox.getChildren().addAll(Logout,Exit);
    hbox.setPadding(new Insets(10,10,10,10));
    hbox.setSpacing(50);
    
    
    VBox vBox = new VBox();
    vBox.getChildren().addAll(welcomingLabel,waitertable,hbox);
   
    
    Logout.setOnAction(e->{
        waitermenu.close();
        
    });
    Exit.setOnAction(e1->{
        System.exit(0);
    });
    Scene scene = new Scene(vBox);
    waitermenu.setScene(scene);
    waitermenu.showAndWait();
    
    }
    public int getNumberofthetable() {
        return numberofthetable;
    }

    public void setNumberofthetable(int numberofthetable) {
        this.numberofthetable = numberofthetable;
    }
    
    public ObservableList<Waiter> WaiterList() throws JAXBException{
        ObservableList<Waiter> lists = FXCollections.observableArrayList();
        Waiter tw[] = new Waiter[100];
        int i=0; 
        JAXBContext jaxbContext = JAXBContext.newInstance(ReservationList.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        ReservationList reservationlist = (ReservationList)unmarshaller.unmarshal(new File("save.xml"));
    for(Waiter waiter:reservationlist.getWaiters().getWaitersXML()){ 
       tw[i]=new Waiter();
        tw[i].setNameofthecustomer(waiter.getNameofthecustomer());
        tw[i].setNumberofthetable(waiter.getNumberofthetable());
       lists.add(new Waiter(tw[i].getNameofthecustomer(),tw[i].getNumberofthetable()));
        i++;
    }
    return lists;}
        
    }

