package javaapplication10;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;


public class JavaApplication10 extends Application implements EventHandler<ActionEvent>{
    Button submit;
   Stage primaryStage =new Stage();
    
   public static void main(String[] args){
        launch(args);
           
    }
    public boolean check(String username,String pass) throws JAXBException{
        int i = 0;
        boolean x=false;
        User U1[]=new User[100];
        JAXBContext jaxbContext = JAXBContext.newInstance(RestaurantUsers.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        RestaurantUsers restaurant = (RestaurantUsers) unmarshaller.unmarshal(new File("Restaurant.xml")); 
        for(User user:restaurant.getUsers().getUsers()){
        U1[i]=new User();
        U1[i].setName(user.getName());
        U1[i].setPassword(user.getPassword());
        U1[i].setRole(user.getRole());
        U1[i].setUsername(user.getUsername());
            if(username.equals(U1[i].getUsername())&&pass.equals(U1[i].getPassword())==true){
     x=true;
     break;
     }i++;}
    return x;
    }
    
     public User check2(String username,String pass) throws JAXBException{
        String y="";
        int i=0;
        User U1[] =new User[100]; 
        JAXBContext jaxbContext = JAXBContext.newInstance(RestaurantUsers.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        RestaurantUsers restaurant = (RestaurantUsers)unmarshaller.unmarshal(new File("Restaurant.xml"));
        
        for(User user:restaurant.getUsers().getUsers()){
        U1[i]=new User();
        U1[i].setName(user.getName());
        U1[i].setPassword(user.getPassword());
        U1[i].setRole(user.getRole());
        U1[i].setUsername(user.getUsername());
        
        if(username.equals(U1[i].getUsername())&&pass.equals(U1[i].getPassword())==true){
        return U1[i];
     }
       i++;}
    return U1[i];
    }
     Customer customer = new Customer();
     Waiter waiter = new Waiter();
     Manager manager = new Manager();
     Cooker cooker = new Cooker();
     public void checkroles(User U1) throws JAXBException{
        
         switch (U1.getRole()) {
            case "Manager":
                manager.ManagerDashboard(U1.getName());
                break;
            case "Client":
                customer.displayCustomer(U1.getName());
                break;
            case "Cooker":
                cooker.CookerDashboard(U1.getName());
                break;
            case "Waiter":
               waiter.Waiterdashboard(U1.getName()); ;
                break;
            default:
                break;
        }
       }   
     
     @Override
    public void start(Stage primaryStage) throws Exception{
    primaryStage.setTitle("Restaurant Reservation");
    GridPane grid = new GridPane();
    
    grid.setPadding(new Insets(11,11,11,11));
    grid.setVgap(2);
    grid.setHgap(5);
    
     TextField UsernameTextField = new TextField();
     PasswordField PasswordField = new PasswordField();
   
    
    Label UsernameLabel = new Label("Username:");
    Label PasswordLabel = new Label("Password:");
    
    GridPane.setConstraints(UsernameLabel, 0, 0);
    GridPane.setConstraints(PasswordLabel, 0, 1);
    
    
    GridPane.setConstraints(UsernameTextField, 4, 0);
    GridPane.setConstraints(PasswordField, 4, 1);
    
    Button Login = new Button ("Login");
    Login.setOnAction(e->{
        try {
            if(check((UsernameTextField.getText()),PasswordField.getText())==false){
                Stage alert = new Stage();
                Label error=new Label("The Password or Username may be invaild");
                Button tryagain=new Button("Try to login again");
                VBox vbox = new VBox();
                vbox.setPadding(new Insets(10,10,10,10));
      vbox.getChildren().addAll(error,tryagain);
       Scene scene = new Scene(vbox);
       tryagain.setOnAction(e2->alert.close());
       alert.setScene(scene);
      alert.showAndWait();
                UsernameTextField.clear();
            PasswordField.clear();}
   
            if(check((UsernameTextField.getText()),PasswordField.getText())==true){
            checkroles(check2(UsernameTextField.getText(),PasswordField.getText()));
            UsernameTextField.clear();
            PasswordField.clear();}
         
        } catch (JAXBException ex) {
            Logger.getLogger(JavaApplication10.class.getName()).log(Level.SEVERE, null, ex);
        }
    });
    GridPane.setConstraints(Login, 2, 2);
    
    grid.getChildren().addAll(UsernameLabel,Login,PasswordField,PasswordLabel,UsernameTextField);
    
    Scene scene = new Scene(grid,300,250);
    primaryStage.setScene(scene);
    primaryStage.show();
    }
    
    @Override
    public void handle(ActionEvent event) {
      }
}
