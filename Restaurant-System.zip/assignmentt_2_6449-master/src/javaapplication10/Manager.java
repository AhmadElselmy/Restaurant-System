package javaapplication10;

import java.io.File;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name = "manager")
@XmlAccessorType(XmlAccessType.FIELD)
public class Manager extends Person{
    @XmlElement(name= "NameOfTheCustomer")
    private String nameofthecustomer;
    @XmlElement(name= "NumberOfTheTable")
    private int numberofthetable;
    @XmlElement(name= "Order")
    private List<String> order;
    @XmlElement(name= "Quantity")
    private List<Integer> quantity;
    @XmlElement(name= "PricePayed")
    private double pricepayed;
Manager tm[] = new Manager[100];
double total=0;
     

public Manager(){
    }
    
    public Manager(String clientname,int tableNumber,List<String> ordername,List<Integer> quantity,double pricepayed){
        this.nameofthecustomer=clientname;
        this.numberofthetable=tableNumber;
        this.order=ordername;
        this.quantity=quantity;
        this.pricepayed=pricepayed;
    }
   
    public String getNameofthecustomer() {
        return nameofthecustomer;
    }

    public void setNameofthecustomer(String nameofthecustomer) {
        this.nameofthecustomer = nameofthecustomer;
    }

    public int getNumberofthetable() {
        return numberofthetable;
    }

    public void setNumberofthetable(int numberofthetable) {
        this.numberofthetable = numberofthetable;
    }

    public List<String> getOrder() {
        return order;
    }

    public void setOrder(List<String> order) {
        this.order = order;
    }

    public List<Integer> getQuantity() {
        return quantity;
    }

    public void setQuantity(List<Integer> quantity) {
        this.quantity = quantity;
    }

    public double getPricepayed() {
        return pricepayed;
    }

    public void setPricepayed(double pricepayed) {
        this.pricepayed = pricepayed;
    }

public void ManagerDashboard(String name) throws JAXBException{
    Stage managermenu = new Stage();
    managermenu.setTitle("Manager's Menu");
    Label welcomingLabel = new Label("Welcome "+ name+"!");
    Label totalprice = new Label("Total Earnings:");
    Label earnings = new Label("0.0");
    TableView<Manager> managertable;
    Button Find = new Button("Find Total Earnings for today ");
    Button Logout = new Button("Logout");
    Button Exit = new Button("Exit");
    
  TableColumn<Manager, String> namecolumn = new TableColumn<>("Name of the user");
  TableColumn<Manager, String> numbercolumn = new TableColumn<>("Number of the table");
  TableColumn<Manager, String> ordercolumn = new TableColumn<>("Order Name");
  TableColumn<Manager, String> quantitycolumn = new TableColumn<>("Quantity");
  TableColumn<Manager, String> pricecolumn = new TableColumn<>("Price Payed");
  
  namecolumn.setMinWidth(200);
  numbercolumn.setMinWidth(200);
  ordercolumn.setMinWidth(200);
  quantitycolumn.setMinWidth(200);
  pricecolumn.setMinWidth(200);
  
  namecolumn.setCellValueFactory(new PropertyValueFactory<>("nameofthecustomer"));
  numbercolumn.setCellValueFactory(new PropertyValueFactory<>("numberofthetable"));
  ordercolumn.setCellValueFactory(new PropertyValueFactory<>("order"));
  quantitycolumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
  pricecolumn.setCellValueFactory(new PropertyValueFactory<>("pricepayed"));
  
    managertable= new TableView<>();
    managertable.setItems(ManagerList());
    managertable.getColumns().addAll(namecolumn,numbercolumn,ordercolumn,quantitycolumn,pricecolumn);
  
    HBox hbox = new HBox();
    hbox.getChildren().addAll(Logout,Exit,Find,totalprice,earnings);
    hbox.setPadding(new Insets(10,10,10,10));
    hbox.setSpacing(50);
    
    
    VBox vBox = new VBox();
    vBox.getChildren().addAll(welcomingLabel,managertable,hbox);
   
    Find.setOnAction(e->{
        earnings.setText(Double.toString(total));
    });
    
    Logout.setOnAction(e->{
        managermenu.close();
        
    });
    Exit.setOnAction(e1->{
        System.exit(0);
    });
    Scene scene = new Scene(vBox);
    managermenu.setScene(scene);
    managermenu.showAndWait();
    
    }
      public ObservableList<Manager> ManagerList() throws JAXBException{
        ObservableList<Manager> lists = FXCollections.observableArrayList();
        int i=0;
        JAXBContext jaxbContext = JAXBContext.newInstance(ReservationList.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        ReservationList reservationlist = (ReservationList)unmarshaller.unmarshal(new File("save.xml"));
    for(Manager manager:reservationlist.getManagers().getManagersXML()){ 
       tm[i]=new Manager();
       tm[i].setNameofthecustomer(manager.getNameofthecustomer());
       tm[i].setNumberofthetable(manager.getNumberofthetable());
       tm[i].setOrder(manager.getOrder());
       tm[i].setQuantity(manager.getQuantity());
       tm[i].setPricepayed(manager.getPricepayed());
       lists.add(new Manager(tm[i].getNameofthecustomer(),tm[i].getNumberofthetable(),tm[i].getOrder(),tm[i].getQuantity(),tm[i].getPricepayed()));
     total += tm[i].getPricepayed(); 
       i++;
    }
    return lists;}
  
}
