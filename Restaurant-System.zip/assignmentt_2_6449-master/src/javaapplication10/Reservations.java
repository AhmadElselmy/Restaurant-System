package javaapplication10;

import javax.xml.bind.Marshaller;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class Reservations extends Person {
    private String Namereserved;
    private Table Tablereserved;
    private Dish Dishreserved;

    public String getNamereserved() {
        return Namereserved;
    }

    public void setNamereserved(String Namereserved) {
        this.Namereserved = Namereserved;
    }

    public Table getTablereserved() {
        return Tablereserved;
    }

    public void setTablereserved(Table Tablereserved) {
        this.Tablereserved = Tablereserved;
    }

    public Dish getDishreserved() {
        return Dishreserved;
    }

    public void setDishreserved(Dish Dishreserved) {
        this.Dishreserved = Dishreserved;
    }
    
    
    public void SaveReservation(String name, ArrayList<String> foodordered,ArrayList<String> quantity,Table table,int count,double price) throws JAXBException, FileNotFoundException {
        int p=0;
        Exception exception = new Exception();
    JAXBContext jaxbContext = JAXBContext.newInstance(ReservationList.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    Unmarshaller unmarshaller1 = jaxbContext.createUnmarshaller();
    ReservationList reservationlist = (ReservationList) unmarshaller1.unmarshal(new File("save.xml"));
    
    Waiter waiter = new Waiter();
    Waiters waiters = new Waiters();
    List<Waiter> waiterxmllist = new ArrayList<>();
    
    Cooker cooker = new Cooker();
    Cookers cookers = new Cookers();
    List<Cooker> cookerxmllist = new ArrayList<>();
    
    Manager manager = new Manager();
    Managers managers = new Managers();
    List<Manager> managerxmllist = new ArrayList<>();
    
    int x=table.getNumber();
    if(reservationlist.getWaiters()==null){
        waiter.setNameofthecustomer(name);
        waiter.setNumberofthetable(x);
        waiterxmllist.add(waiter);
        waiters.setWaitersXML(new ArrayList(waiterxmllist));
        reservationlist.setWaiters(waiters);  
        try{
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        OutputStream output = new FileOutputStream("save.xml");
        marshaller.marshal(reservationlist,output);
        }catch (Exception r){
            System.out.println("waiter empty catch"+r);
        }
        }
    else{
    reservationlist.getWaiters().getWaitersXML().add(new Waiter(name,x));
    waiters.setWaitersXML(new ArrayList(reservationlist.getWaiters().getWaitersXML()));
    reservationlist.setWaiters(waiters);
    try{
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        OutputStream output1 = new FileOutputStream("save.xml");
        marshaller.marshal(reservationlist,output1);
    }catch (Exception b){
        System.out.println(b);
    }
    }
    if(reservationlist.getCookers()==null){
        cooker.setNumberofthetable(x);
        cooker.setOrder(new ArrayList(foodordered));
        cooker.setQuantity(new ArrayList(quantity));
        
        cookerxmllist.add(cooker);
        cookers.setCookersXML(new ArrayList(cookerxmllist));
        reservationlist.setCookers(cookers);  
        try{
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        OutputStream output = new FileOutputStream("save.xml");
        marshaller.marshal(reservationlist,output);
        }catch (Exception r){
            System.out.println("waiter empty catch"+r);
        }
        }
    else{
    reservationlist.getCookers().getCookersXML().add(new Cooker(new ArrayList(foodordered),new ArrayList(quantity),table.getNumber())); 
    cookers.setCookersXML(new ArrayList(reservationlist.getCookers().getCookersXML()));
    reservationlist.setCookers(cookers);
    try{
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        OutputStream output1 = new FileOutputStream("save.xml");
        marshaller.marshal(reservationlist,output1);
    }catch (Exception b){
        System.out.println(b);
    }
    }
    
    if(reservationlist.getManagers()==null){
        manager.setNumberofthetable(x);
        manager.setOrder(new ArrayList(foodordered));
        manager.setQuantity(new ArrayList(quantity));
        manager.setNameofthecustomer(name);
        manager.setPricepayed(price);
        managerxmllist.add(manager);
        managers.setManagersXML(new ArrayList(managerxmllist));
        reservationlist.setManagers(managers);  
        try{
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        OutputStream output = new FileOutputStream("save.xml");
        marshaller.marshal(reservationlist,output);
        }catch (Exception r){
            System.out.println("waiter empty catch"+r);
        }
        }
    else{
    reservationlist.getManagers().getManagersXML().add(new Manager(name,table.getNumber(),new ArrayList(foodordered),new ArrayList(quantity),price));
    managers.setManagersXML(new ArrayList(reservationlist.getManagers().getManagersXML()));
    reservationlist.setManagers(managers);
    try{
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        OutputStream output1 = new FileOutputStream("save.xml");
        marshaller.marshal(reservationlist,output1);
    }catch (Exception b){
        System.out.println(b);
    }
    }
    
    }
    }

