package javaapplication10;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class JavaApplication10 {
    public static void main(String[] args) throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(Restaurant.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        Restaurant restaurant = (Restaurant)unmarshaller.unmarshal(new File("Restaurant.xml"));
        
        for(User user:restaurant.getUsers().getUsers()){
            System.out.println(user.getName()+" "+user.getRole()+" "+user.getUsername());
        }
    Marshaller marshaller = jaxbContext.createMarshaller();
    Restaurant savedRestaurant = new Restaurant();
    Users users = new Users();
    User user = new User();
    user.setRole("customer");
    user.setUsername("selmy");
    user.setName("Mark");
    user.setPassword("12113");
    List<User> userList = new ArrayList<>();
    userList.add(user);
    users.setUsers(userList);
    savedRestaurant.setUsers(users);
    
    marshaller.marshal(savedRestaurant,new File("save.xml"));
    }
    
}
